## Global Components for each ESP32 Sub-project

The files in this directory allow us to create reusable components for use in all of the esp-idf sub-projects.